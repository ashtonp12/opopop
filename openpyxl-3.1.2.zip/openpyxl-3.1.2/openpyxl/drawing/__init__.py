# Copyright (c) 2010-2023 openpyxl


from .drawing import Drawing
