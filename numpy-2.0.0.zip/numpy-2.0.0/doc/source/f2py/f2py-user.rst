.. _f2py-user:

F2PY user guide
===============

.. toctree::
   :maxdepth: 2

   f2py.getting-started
   usage
   f2py-examples